import SwiftUI

struct TwoView:View {
    var body: some View {
        Text("Two")
    }
}
