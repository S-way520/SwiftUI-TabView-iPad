import SwiftUI

struct Bar: View {
    var body: some View {
        TabView {
            OneView().tabItem {
                Image(systemName: "house")
                Text("主页")
            }
            TwoView().tabItem{
                Image(systemName: "mappin.and.ellipse")
                Text("周边")
            }
            ThreeView().tabItem{
                Image(systemName: "person.fill")
                Text("我的")
            }
        }
        .edgesIgnoringSafeArea(.all)
        .accentColor(Color.red)//Button Color
        .onAppear(perform: {
            UITabBar.appearance().backgroundImage = UIImage()
            UITabBar.appearance().shadowImage = UIImage()
            //UITabBar.appearance().unselectedItemTintColor = UIColor.gray
        })
    }
}


