import SwiftUI

struct OneView:View {
    var body: some View {
        Text("One")
    }
}
